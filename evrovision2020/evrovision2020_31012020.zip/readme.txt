1) Заменены файлы:
  i/logo_top3.png
  i/bg_top3.jpg
  i/1.jpg

2) Изменен css/index.css
3) Изменен js/common.css
4) в html удалена строка <img src="i/bg_footer.jpg" width="937" height="135" alt=""/>
